# Enhanced Drilling Rig Components Dashboard

## Overview

This is a professional, modern web-based dashboard designed specifically for oil and gas field professionals to manage and monitor drilling rig components. The dashboard provides comprehensive information about drilling equipment, including technical specifications, safety protocols, maintenance schedules, and operational procedures.

## Key Features

### 🔍 **Advanced Search & Filtering**
- Real-time search functionality across all components
- Category-based filtering (Hoisting System, Safety System, Circulation System, Rotation System)
- Instant results with component count display

### 📊 **Key Performance Indicators (KPIs)**
- Real-time efficiency monitoring
- Equipment uptime tracking
- Color-coded performance indicators
- Maintenance status tracking

### 🛡️ **Comprehensive Safety Information**
- Safety risk level classification (Critical, High, Medium)
- Detailed safety warnings and procedures
- Emergency response protocols
- Pre-operation checklists

### 🔧 **Maintenance Management**
- Scheduled maintenance tracking
- Task-specific maintenance procedures
- Next due date monitoring
- Maintenance history tracking

### 📋 **Technical Specifications**
- Detailed equipment specifications
- Operating parameters and limits
- Material and capacity information
- Temperature and pressure ratings

### 📱 **Responsive Design**
- Mobile-friendly interface
- Tablet and desktop optimization
- Touch-friendly navigation
- Cross-browser compatibility

## Components Included

The dashboard includes detailed information for the following critical drilling rig components:

1. **Crown Block and Water Table** - Hoisting System
2. **Traveling Block** - Hoisting System
3. **Blowout Preventer (BOP)** - Safety System
4. **Mud Pumps** - Circulation System
5. **Drawworks** - Hoisting System
6. **Rotary Table** - Rotation System

Each component includes:
- High-quality technical diagrams and photos
- Complete technical specifications
- Safety warnings and procedures
- Maintenance schedules and tasks
- Operating procedures and emergency protocols

## Technology Stack

- **Frontend**: React 18 with modern hooks
- **Styling**: Tailwind CSS with custom industrial theme
- **UI Components**: shadcn/ui component library
- **Icons**: Lucide React icons
- **Build Tool**: Vite for fast development and building
- **Package Manager**: pnpm for efficient dependency management

## Installation & Setup

### Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm

### Development Setup
```bash
# Clone or extract the project
cd drilling-rig-dashboard

# Install dependencies
pnpm install

# Start development server
pnpm run dev --host

# Access the dashboard
# Local: http://localhost:5173/
# Network: http://[your-ip]:5173/
```

### Production Build
```bash
# Build for production
pnpm run build

# Preview production build
pnpm run preview --host
```

## Usage Guide

### Navigation
1. **Search Components**: Use the search bar to find specific components by name or description
2. **Filter by Category**: Select a category from the dropdown to filter components
3. **Select Component**: Click on any component in the sidebar to view detailed information

### Component Details
Each component provides four main information tabs:

#### 📊 Specifications Tab
- Technical specifications and operating parameters
- Load capacities, pressure ratings, and material information
- Operating temperature ranges and power requirements

#### 🛡️ Safety Tab
- Safety risk level and warnings
- Required safety procedures and protocols
- Emergency response guidelines

#### 🔧 Maintenance Tab
- Maintenance frequency and scheduling
- Last maintenance date and next due date
- Specific maintenance tasks and procedures

#### 📖 Procedures Tab
- Pre-operation checklists
- Emergency procedures and protocols
- Step-by-step operating guidelines

### Key Performance Indicators
- **Efficiency**: Equipment operational efficiency percentage
- **Uptime**: Equipment availability and reliability percentage
- **Color Coding**: 
  - Green (98%+): Excellent performance
  - Yellow (95-97%): Good performance
  - Red (<95%): Requires attention

## Safety Features

### Risk Classification
- **Critical Risk**: Components essential for well control and safety
- **High Risk**: Components with significant safety implications
- **Medium Risk**: Standard operational equipment

### Safety Protocols
- Pre-shift inspection requirements
- Emergency stop procedures
- Lockout/tagout protocols
- Personal protective equipment (PPE) requirements

## Maintenance Management

### Scheduling
- Daily, weekly, and monthly maintenance schedules
- Automated next due date calculations
- Maintenance task tracking and completion

### Procedures
- Component-specific maintenance tasks
- Lubrication schedules and requirements
- Inspection protocols and checklists

## Customization

### Adding New Components
To add new drilling rig components, modify the `drillingComponents` array in `src/App.jsx`:

```javascript
{
  id: 'component-id',
  name: 'Component Name',
  category: 'System Category',
  description: 'Component description',
  image: componentImage,
  specifications: {
    'Spec Name': 'Spec Value'
  },
  safety: {
    level: 'Critical|High|Medium',
    warnings: ['Warning 1', 'Warning 2'],
    procedures: ['Procedure 1', 'Procedure 2']
  },
  maintenance: {
    frequency: 'Daily|Weekly|Monthly',
    tasks: ['Task 1', 'Task 2'],
    nextDue: 'YYYY-MM-DD'
  },
  kpis: {
    efficiency: 95,
    uptime: 98.5,
    lastMaintenance: 'YYYY-MM-DD'
  }
}
```

### Styling Customization
- Modify `src/App.css` for custom styling
- Update Tailwind configuration in `tailwind.config.js`
- Customize color themes and component styling

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Fast initial load with code splitting
- Optimized images and assets
- Responsive design for all screen sizes
- Efficient search and filtering algorithms

## Security Considerations

- No external API dependencies for core functionality
- Client-side only application
- No sensitive data storage
- HTTPS recommended for production deployment

## Deployment Options

### Static Hosting
- Netlify, Vercel, or GitHub Pages
- AWS S3 with CloudFront
- Any static file hosting service

### Self-Hosted
- Nginx or Apache web server
- Docker containerization
- Internal company servers

## Support & Maintenance

### Regular Updates
- Component information updates
- Safety protocol revisions
- Maintenance schedule adjustments
- Performance optimizations

### Monitoring
- Track component performance metrics
- Monitor maintenance compliance
- Update safety procedures as needed

## License

This dashboard is designed for professional use in oil and gas drilling operations. Ensure compliance with industry safety standards and regulations.

## Contact

For technical support, customization requests, or additional features, please contact your system administrator or development team.

---

**Important Safety Notice**: This dashboard is a tool for information management and should not replace proper safety training, equipment inspection, or adherence to industry safety standards. Always follow established safety protocols and consult with qualified personnel for critical operations.

