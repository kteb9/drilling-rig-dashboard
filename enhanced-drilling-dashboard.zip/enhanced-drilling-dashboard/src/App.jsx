import { useState, useMemo } from 'react'
import { Search, Filter, AlertTriangle, Wrench, BookOpen, BarChart3, Settings, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import './App.css'

// Import images
import travelingBlockImg from './assets/search_images/EIlejmLKwEhK.jpg'
import crownBlockImg from './assets/search_images/S5UIjBGmfj4F.gif'
import crownBlockDiagramImg from './assets/search_images/GW8gHjnqy5fI.jpg'
import bopImg from './assets/search_images/zhtnnO7SBI5w.webp'
import bopDiagramImg from './assets/search_images/OnIEGY6SngR7.png'
import bopSystemImg from './assets/search_images/A3JUba92JRHg.jpg'
import rotaryRigImg from './assets/search_images/0s4RadWbxqoO.jpg'
import rigDiagramImg from './assets/search_images/aLiFjZGzu37r.jpg'

const drillingComponents = [
  {
    id: 'crown-block',
    name: 'Crown Block and Water Table',
    category: 'Hoisting System',
    description: 'An assembly of sheaves or pulleys mounted on beams at the top of the derrick. The drilling line is run over the sheaves down to the hoisting drum.',
    image: crownBlockImg,
    specifications: {
      'Load Capacity': '500-1500 tons',
      'Number of Sheaves': '4-10',
      'Material': 'High-strength steel',
      'Operating Temperature': '-40°C to +80°C'
    },
    safety: {
      level: 'Critical',
      warnings: ['Regular inspection of wire rope required', 'Load limits must not be exceeded', 'Proper lubrication essential'],
      procedures: ['Daily visual inspection', 'Weekly load test', 'Monthly detailed inspection']
    },
    maintenance: {
      frequency: 'Weekly',
      tasks: ['Lubricate sheaves', 'Check wire rope condition', 'Inspect mounting bolts'],
      nextDue: '2025-01-15'
    },
    kpis: {
      efficiency: 98,
      uptime: 99.2,
      lastMaintenance: '2025-01-08'
    }
  },
  {
    id: 'traveling-block',
    name: 'Traveling Block',
    category: 'Hoisting System',
    description: 'An arrangement of pulleys or sheaves through which drilling cable is reeved, which moves up or down in the derrick or mast.',
    image: travelingBlockImg,
    specifications: {
      'Load Capacity': '300-1000 tons',
      'Number of Sheaves': '3-6',
      'Weight': '15-50 tons',
      'Hook Load Rating': '500-1500 tons'
    },
    safety: {
      level: 'Critical',
      warnings: ['Never exceed rated load capacity', 'Inspect hook and safety latch daily', 'Check for wire rope wear'],
      procedures: ['Pre-shift inspection', 'Load test certification', 'Emergency stop procedures']
    },
    maintenance: {
      frequency: 'Daily',
      tasks: ['Visual inspection', 'Lubricate bearings', 'Check safety systems'],
      nextDue: '2025-01-09'
    },
    kpis: {
      efficiency: 97,
      uptime: 98.8,
      lastMaintenance: '2025-01-08'
    }
  },
  {
    id: 'blowout-preventer',
    name: 'Blowout Preventer (BOP)',
    category: 'Safety System',
    description: 'A large valve, usually installed above the ram preventers, that forms a seal in the annular space between the pipe and well bore or, if no pipe is present, on the well bore itself.',
    image: bopImg,
    specifications: {
      'Working Pressure': '2000-15000 psi',
      'Bore Size': '13 3/8" - 30"',
      'Operating Medium': 'Hydraulic fluid',
      'Response Time': '< 30 seconds'
    },
    safety: {
      level: 'Critical',
      warnings: ['Primary well control device', 'Must be tested before drilling', 'Emergency backup systems required'],
      procedures: ['Function test every 14 days', 'Pressure test weekly', 'Emergency drill monthly']
    },
    maintenance: {
      frequency: 'Weekly',
      tasks: ['Pressure test', 'Function test all rams', 'Check hydraulic fluid levels'],
      nextDue: '2025-01-12'
    },
    kpis: {
      efficiency: 99,
      uptime: 99.9,
      lastMaintenance: '2025-01-05'
    }
  },
  {
    id: 'mud-pumps',
    name: 'Mud Pumps',
    category: 'Circulation System',
    description: 'A large reciprocating pump used to circulate the mud (drilling fluid) on a drilling rig.',
    image: rotaryRigImg,
    specifications: {
      'Flow Rate': '350-1200 gpm',
      'Pressure Rating': '3000-7500 psi',
      'Power': '1000-3000 HP',
      'Stroke Rate': '40-120 spm'
    },
    safety: {
      level: 'High',
      warnings: ['High pressure system', 'Moving parts hazard', 'Noise protection required'],
      procedures: ['Pressure relief before maintenance', 'Lockout/tagout procedures', 'PPE requirements']
    },
    maintenance: {
      frequency: 'Daily',
      tasks: ['Check fluid levels', 'Inspect valves', 'Monitor pressure gauges'],
      nextDue: '2025-01-09'
    },
    kpis: {
      efficiency: 95,
      uptime: 97.5,
      lastMaintenance: '2025-01-08'
    }
  },
  {
    id: 'drawworks',
    name: 'Drawworks',
    category: 'Hoisting System',
    description: 'The hoisting mechanism on a drilling rig. It is essentially a large winch that spools off or takes in the drilling line and thus raises or lowers the drill stem and bit.',
    image: rigDiagramImg,
    specifications: {
      'Power Rating': '1000-3000 HP',
      'Line Pull': '300-1500 tons',
      'Drum Capacity': '3000-8000 ft',
      'Brake Type': 'Electromagnetic/Hydraulic'
    },
    safety: {
      level: 'Critical',
      warnings: ['High torque rotating equipment', 'Brake system critical', 'Emergency stop required'],
      procedures: ['Brake test daily', 'Emergency stop test', 'Load monitoring']
    },
    maintenance: {
      frequency: 'Weekly',
      tasks: ['Brake inspection', 'Lubricate gears', 'Check wire rope'],
      nextDue: '2025-01-14'
    },
    kpis: {
      efficiency: 96,
      uptime: 98.2,
      lastMaintenance: '2025-01-07'
    }
  },
  {
    id: 'rotary-table',
    name: 'Rotary Table',
    category: 'Rotation System',
    description: 'The principal component of a rotary, or rotary machine, used to turn the drill stem and support the drilling assembly.',
    image: crownBlockDiagramImg,
    specifications: {
      'Torque Rating': '50000-150000 ft-lbs',
      'Rotary Speed': '0-300 RPM',
      'Table Opening': '17 1/2" - 37 1/2"',
      'Power': '500-1500 HP'
    },
    safety: {
      level: 'High',
      warnings: ['Rotating machinery hazard', 'Pinch points present', 'Proper guarding required'],
      procedures: ['Lockout before maintenance', 'Emergency stop accessible', 'Guard inspection']
    },
    maintenance: {
      frequency: 'Weekly',
      tasks: ['Lubricate bearings', 'Check drive chains', 'Inspect guards'],
      nextDue: '2025-01-13'
    },
    kpis: {
      efficiency: 94,
      uptime: 96.8,
      lastMaintenance: '2025-01-06'
    }
  }
]

const categories = ['All', 'Hoisting System', 'Safety System', 'Circulation System', 'Rotation System']

function App() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedComponent, setSelectedComponent] = useState(null)

  const filteredComponents = useMemo(() => {
    return drillingComponents.filter(component => {
      const matchesSearch = component.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          component.description.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === 'All' || component.category === selectedCategory
      return matchesSearch && matchesCategory
    })
  }, [searchTerm, selectedCategory])

  const getSafetyBadgeColor = (level) => {
    switch (level) {
      case 'Critical': return 'destructive'
      case 'High': return 'secondary'
      default: return 'default'
    }
  }

  const getKPIColor = (value) => {
    if (value >= 98) return 'text-green-600'
    if (value >= 95) return 'text-yellow-600'
    return 'text-red-600'
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Settings className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Drilling Rig Components Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-600">
                System Online
              </Badge>
              <Badge variant="outline">
                {drillingComponents.length} Components
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="lg:w-1/3 space-y-6">
            {/* Search and Filter */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Search & Filter
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search components..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Components List */}
            <Card>
              <CardHeader>
                <CardTitle>Components ({filteredComponents.length})</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {filteredComponents.map(component => (
                    <div
                      key={component.id}
                      className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                        selectedComponent?.id === component.id ? 'bg-blue-50 border-blue-200' : ''
                      }`}
                      onClick={() => setSelectedComponent(component)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-medium text-sm">{component.name}</h3>
                          <p className="text-xs text-gray-500 mt-1">{component.category}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-xs">
                              {component.kpis.uptime}% Uptime
                            </Badge>
                            <Badge variant={getSafetyBadgeColor(component.safety.level)} className="text-xs">
                              {component.safety.level}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:w-2/3">
            {selectedComponent ? (
              <div className="space-y-6">
                {/* Component Header */}
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{selectedComponent.name}</CardTitle>
                        <CardDescription className="mt-2">
                          {selectedComponent.description}
                        </CardDescription>
                      </div>
                      <Badge variant={getSafetyBadgeColor(selectedComponent.safety.level)}>
                        <Shield className="h-3 w-3 mr-1" />
                        {selectedComponent.safety.level} Risk
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="md:w-1/2">
                        <img
                          src={selectedComponent.image}
                          alt={selectedComponent.name}
                          className="w-full h-48 object-cover rounded-lg border"
                        />
                      </div>
                      <div className="md:w-1/2 space-y-4">
                        <div>
                          <h4 className="font-semibold text-sm text-gray-700 mb-2">Key Performance Indicators</h4>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="text-center p-3 bg-gray-50 rounded">
                              <div className={`text-lg font-bold ${getKPIColor(selectedComponent.kpis.efficiency)}`}>
                                {selectedComponent.kpis.efficiency}%
                              </div>
                              <div className="text-xs text-gray-500">Efficiency</div>
                            </div>
                            <div className="text-center p-3 bg-gray-50 rounded">
                              <div className={`text-lg font-bold ${getKPIColor(selectedComponent.kpis.uptime)}`}>
                                {selectedComponent.kpis.uptime}%
                              </div>
                              <div className="text-xs text-gray-500">Uptime</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <Badge variant="outline" className="text-xs">
                            Category: {selectedComponent.category}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Information Tabs */}
                <Card>
                  <CardContent className="p-0">
                    <Tabs defaultValue="specifications" className="w-full">
                      <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="specifications" className="flex items-center gap-2">
                          <BarChart3 className="h-4 w-4" />
                          Specs
                        </TabsTrigger>
                        <TabsTrigger value="safety" className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4" />
                          Safety
                        </TabsTrigger>
                        <TabsTrigger value="maintenance" className="flex items-center gap-2">
                          <Wrench className="h-4 w-4" />
                          Maintenance
                        </TabsTrigger>
                        <TabsTrigger value="procedures" className="flex items-center gap-2">
                          <BookOpen className="h-4 w-4" />
                          Procedures
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="specifications" className="p-6">
                        <h3 className="font-semibold mb-4">Technical Specifications</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {Object.entries(selectedComponent.specifications).map(([key, value]) => (
                            <div key={key} className="flex justify-between p-3 bg-gray-50 rounded">
                              <span className="font-medium text-sm">{key}:</span>
                              <span className="text-sm text-gray-600">{value}</span>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="safety" className="p-6">
                        <h3 className="font-semibold mb-4">Safety Information</h3>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                              <AlertTriangle className="h-4 w-4 text-red-500" />
                              Safety Warnings
                            </h4>
                            <ul className="space-y-1">
                              {selectedComponent.safety.warnings.map((warning, index) => (
                                <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                                  <span className="text-red-500 mt-1">•</span>
                                  {warning}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-medium text-sm mb-2">Safety Procedures</h4>
                            <ul className="space-y-1">
                              {selectedComponent.safety.procedures.map((procedure, index) => (
                                <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                                  <span className="text-blue-500 mt-1">•</span>
                                  {procedure}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="maintenance" className="p-6">
                        <h3 className="font-semibold mb-4">Maintenance Schedule</h3>
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="p-3 bg-blue-50 rounded">
                              <div className="text-sm font-medium text-blue-700">Frequency</div>
                              <div className="text-lg font-bold text-blue-900">{selectedComponent.maintenance.frequency}</div>
                            </div>
                            <div className="p-3 bg-green-50 rounded">
                              <div className="text-sm font-medium text-green-700">Last Maintenance</div>
                              <div className="text-lg font-bold text-green-900">{selectedComponent.kpis.lastMaintenance}</div>
                            </div>
                            <div className="p-3 bg-orange-50 rounded">
                              <div className="text-sm font-medium text-orange-700">Next Due</div>
                              <div className="text-lg font-bold text-orange-900">{selectedComponent.maintenance.nextDue}</div>
                            </div>
                          </div>
                          <div>
                            <h4 className="font-medium text-sm mb-2">Maintenance Tasks</h4>
                            <ul className="space-y-1">
                              {selectedComponent.maintenance.tasks.map((task, index) => (
                                <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                                  <span className="text-green-500 mt-1">✓</span>
                                  {task}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="procedures" className="p-6">
                        <h3 className="font-semibold mb-4">Operating Procedures</h3>
                        <div className="space-y-4">
                          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
                            <h4 className="font-medium text-sm text-yellow-800 mb-2">Pre-Operation Checklist</h4>
                            <ul className="text-sm text-yellow-700 space-y-1">
                              <li>• Visual inspection for damage or wear</li>
                              <li>• Check all safety systems</li>
                              <li>• Verify proper lubrication</li>
                              <li>• Test emergency stops</li>
                            </ul>
                          </div>
                          <div className="p-4 bg-blue-50 border border-blue-200 rounded">
                            <h4 className="font-medium text-sm text-blue-800 mb-2">Emergency Procedures</h4>
                            <ul className="text-sm text-blue-700 space-y-1">
                              <li>• Activate emergency stop immediately</li>
                              <li>• Isolate power sources</li>
                              <li>• Follow lockout/tagout procedures</li>
                              <li>• Contact supervisor and safety personnel</li>
                            </ul>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="h-96 flex items-center justify-center">
                <CardContent className="text-center">
                  <Settings className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Component</h3>
                  <p className="text-gray-500">Choose a drilling rig component from the sidebar to view detailed information, specifications, and maintenance data.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default App

